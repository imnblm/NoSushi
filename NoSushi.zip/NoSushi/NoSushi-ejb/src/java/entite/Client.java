
package entite;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;


@Entity
public class Client implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 80)
    private String cltPseudo;
    private String cltNom;
    private String cltPrenom;
    
    @Column(nullable = false, length = 24)
    private String cltMdp;
    
    @Column(nullable = false, unique = true)
    private String cltEmail;
    
    private int cltPoints;
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date cltDebut;
    private String cltEtat;
    
    @Column(unique = true)
    private String cltLogin;

    public Client() {
    }

    public Client(String pseudo, String mdp, String email) {
        this.cltPseudo = pseudo;
        this.cltMdp = mdp;
        this.cltEmail = email;
    }

    public Client(String pseudo, String nom, String prenom, String mdp, String email, String login) {
        this.cltPseudo = pseudo;
        this.cltNom = nom;
        this.cltPrenom = prenom;
        this.cltMdp = mdp;
        this.cltEmail = email;
        this.cltLogin = login;
    }

    public Client(String pseudo, String nom, String prenom, String mdp, String email, int points, Date debut, String etat, String login) {
        this.cltPseudo = pseudo;
        this.cltNom = nom;
        this.cltPrenom = prenom;
        this.cltMdp = mdp;
        this.cltEmail = email;
        this.cltPoints = points;
        this.cltDebut = debut;
        this.cltEtat = etat;
        this.cltLogin = login;
    }

    public String getCltPseudo() {
        return cltPseudo;
    }

    public void setCltPseudo(String cltPseudo) {
        this.cltPseudo = cltPseudo;
    }

    public String getCltNom() {
        return cltNom;
    }

    public void setCltNom(String cltNom) {
        this.cltNom = cltNom;
    }

    public String getCltPrenom() {
        return cltPrenom;
    }

    public void setCltPrenom(String cltPrenom) {
        this.cltPrenom = cltPrenom;
    }

    public String getCltMdp() {
        return cltMdp;
    }

    public void setCltMdp(String cltMdp) {
        this.cltMdp = cltMdp;
    }

    public String getCltEmail() {
        return cltEmail;
    }

    public void setCltEmail(String cltEmail) {
        this.cltEmail = cltEmail;
    }

    public int getCltPoints() {
        return cltPoints;
    }

    public void setCltPoints(int cltPoints) {
        this.cltPoints = cltPoints;
    }

    public Date getCltDebut() {
        return cltDebut;
    }

    public void setCltDebut(Date cltDebut) {
        this.cltDebut = cltDebut;
    }

    public String getCltEtat() {
        return cltEtat;
    }

    public void setCltEtat(String cltEtat) {
        this.cltEtat = cltEtat;
    }

    public String getCltLogin() {
        return cltLogin;
    }

    public void setCltLogin(String cltLogin) {
        this.cltLogin = cltLogin;
    }


    
    
    
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Client)) {
            return false;
        }
        Client other = (Client) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Client{" + "id : " + id + ", pseudo : " + cltPseudo + ", nom : " + cltNom
                + ", prenom : " + cltPrenom + ", mdp : " + cltMdp + ", email : " + cltEmail
                + ", points : " + cltPoints + ", debut : " + cltDebut + ", etat : " + cltEtat + ", login : " + cltLogin + '}';
    }


    
}
