package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Commande implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    private Date cmdDate;
   
    @Column(nullable = false, length = 100)
    private String cmdEtat;
    
    @OneToMany(mappedBy = "commande")
    private Collection<LigneCommande> lignescmd;

    public Commande() {
        lignescmd = new ArrayList();
    }

    public Commande(Date cmdDate, String cmdEtat) {
        this();
        this.cmdDate = cmdDate;
        this.cmdEtat = cmdEtat;
    }

    public Collection<LigneCommande> getLignescmd() {
        return lignescmd;
    }

    public void setLignescmd(Collection<LigneCommande> lignescmd) {
        this.lignescmd = lignescmd;
    }
    
    public Date getCmdDate() {
        return cmdDate;
    }

    public void setCmdDate(Date cmdDate) {
        this.cmdDate = cmdDate;
    }

    public String getCmdEtat() {
        return cmdEtat;
    }

    public void setCmdEtat(String cmdEtat) {
        this.cmdEtat = cmdEtat;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Commande)) {
            return false;
        }
        Commande other = (Commande) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entite.Commande[ id=" + id + " ]";
    }
    
}
