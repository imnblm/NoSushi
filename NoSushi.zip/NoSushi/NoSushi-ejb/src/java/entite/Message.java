
package entite;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
public class Message implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    @Column(nullable = false, length = 50)
    private String messType;
    
    @Column
    private String messLibelle;
    
    @Column
    private String messCom;    
    
   @Temporal(TemporalType.TIMESTAMP)
    private Date messDateDebut;
   
   @Temporal(TemporalType.TIMESTAMP)
    private Date messDateFin;
   
    @ManyToOne
    private Restaurant restaurant;

    public Message() {
    }

    public Message(String messType, String messLibelle, String messCom, Date messDateDebut, Date messDateFin, Restaurant restaurant) {
        this.messType = messType;
        this.messLibelle = messLibelle;
        this.messCom = messCom;
        this.messDateDebut = messDateDebut;
        this.messDateFin = messDateFin;
        this.restaurant = restaurant;
    }

    public String getMessType() {
        return messType;
    }

    public void setMessType(String messType) {
        this.messType = messType;
    }

    public String getMessLibelle() {
        return messLibelle;
    }

    public void setMessLibelle(String messLibelle) {
        this.messLibelle = messLibelle;
    }

    public String getMessCom() {
        return messCom;
    }

    public void setMessCom(String messCom) {
        this.messCom = messCom;
    }

    public Date getMessDateDebut() {
        return messDateDebut;
    }

    public void setMessDateDebut(Date messDateDebut) {
        this.messDateDebut = messDateDebut;
    }

    public Date getMessDateFin() {
        return messDateFin;
    }

    public void setMessDateFin(Date messDateFin) {
        this.messDateFin = messDateFin;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
   
   
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Message)) {
            return false;
        }
        Message other = (Message) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Message{" + "id=" + id + ", messType=" + messType + ", messLibelle=" + messLibelle + ", messCom=" + messCom + ", messDateDebut=" + messDateDebut + ", messDateFin=" + messDateFin + ", restaurant=" + restaurant + '}';
    }

    
    
}