
package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Caracteristique implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String carLibelle;
    @Column(nullable = false)
    private String carValeur;
    @Column(nullable = false)
    private String carUniteMesure;

    @ManyToMany(mappedBy = "caracteristiques")
    private Collection<Produit> produits;
    
    public Caracteristique() {
        produits = new ArrayList();
    }

    public Caracteristique(String carLibelle) {
        this();
        this.carLibelle = carLibelle;
    }

    public Caracteristique(String carLibelle, String carValeur, String carUniteMesure) {
        this();
        this.carLibelle = carLibelle;
        this.carValeur = carValeur;
        this.carUniteMesure = carUniteMesure;
    }

    public Caracteristique(String carLibelle, String carValeur, String carUniteMesure, Collection<Produit> produits) {
        this();
        this.carLibelle = carLibelle;
        this.carValeur = carValeur;
        this.carUniteMesure = carUniteMesure;
        this.produits = produits;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }
    
    

    public String getCarLibelle() {
        return carLibelle;
    }

    public void setCarLibelle(String carLibelle) {
        this.carLibelle = carLibelle;
    }

    public String getCarValeur() {
        return carValeur;
    }

    public void setCarValeur(String carValeur) {
        this.carValeur = carValeur;
    }

    public String getCarUniteMesure() {
        return carUniteMesure;
    }

    public void setCarUniteMesure(String carUniteMesure) {
        this.carUniteMesure = carUniteMesure;
    }

    
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Caracteristique)) {
            return false;
        }
        Caracteristique other = (Caracteristique) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Caracteristique{" + "id : " + id + ", carLibelle :" + carLibelle 
                + ", carValeur : " + carValeur + ", carUniteMesure :" + carUniteMesure + '}';
    }


    
}
