
package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Menu implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String menuNomFr;
    @Column(nullable = false)
    private String menuNomEn;
    private String menuDescFr;
    private String menuDescEn;
    private Byte menuPhoto;
    @Column(nullable = false)
    private float menuPrix;
    
    @ManyToMany
    private Collection<Produit> produits;

    public Menu() {
        produits = new ArrayList();
    }

    public Menu(String menuNomFr, String menuNomEn) {
        this();
        this.menuNomFr = menuNomFr;
        this.menuNomEn = menuNomEn;
    }

    public Menu(String menuNomFr, String menuNomEn, float menuPrix) {
        this();
        this.menuNomFr = menuNomFr;
        this.menuNomEn = menuNomEn;
        this.menuPrix = menuPrix;
    }

    public Menu(String menuNomFr, String menuNomEn, String menuDescFr, String menuDescEn, float menuPrix) {
        this();
        this.menuNomFr = menuNomFr;
        this.menuNomEn = menuNomEn;
        this.menuDescFr = menuDescFr;
        this.menuDescEn = menuDescEn;
        this.menuPrix = menuPrix;
    }

    public Menu(String menuNomFr, String menuNomEn, String menuDescFr, String menuDescEn, Byte menuPhoto, float menuPrix) {
        this();
        this.menuNomFr = menuNomFr;
        this.menuNomEn = menuNomEn;
        this.menuDescFr = menuDescFr;
        this.menuDescEn = menuDescEn;
        this.menuPhoto = menuPhoto;
        this.menuPrix = menuPrix;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }

    
    
    public String getMenuNomFr() {
        return menuNomFr;
    }

    public void setMenuNomFr(String menuNomFr) {
        this.menuNomFr = menuNomFr;
    }

    public String getMenuNomEn() {
        return menuNomEn;
    }

    public void setMenuNomEn(String menuNomEn) {
        this.menuNomEn = menuNomEn;
    }

    public String getMenuDescFr() {
        return menuDescFr;
    }

    public void setMenuDescFr(String menuDescFr) {
        this.menuDescFr = menuDescFr;
    }

    public String getMenuDescEn() {
        return menuDescEn;
    }

    public void setMenuDescEn(String menuDescEn) {
        this.menuDescEn = menuDescEn;
    }

    public Byte getMenuPhoto() {
        return menuPhoto;
    }

    public void setMenuPhoto(Byte menuPhoto) {
        this.menuPhoto = menuPhoto;
    }

    public float getMenuPrix() {
        return menuPrix;
    }

    public void setMenuPrix(float menuPrix) {
        this.menuPrix = menuPrix;
    }
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Menu)) {
            return false;
        }
        Menu other = (Menu) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Menu{" + "id : " + id + ", menuNomFr : " + menuNomFr + ", menuNomEn : " + menuNomEn 
                + ", menuDescFr : " + menuDescFr + ", menuDescEn : " + menuDescEn + ", menuPhoto : " + menuPhoto 
                + ", menuPrix : " + menuPrix + '}';
    }


    
}
