
package entite;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Allergene implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 100)
    private String allLibelleFr;
    
    @Column(unique = true, nullable = false, length = 100)
    private String allLibelleEn;
    
    @OneToMany(mappedBy = "allergene")
    private Collection<Ingredient> ingredients;

    public Long getId() { 
        return id;
    }

    

    public Collection<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(Collection<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public Allergene() {
    }

    public Allergene(String allLibelleFr, String allLibelleEn) {
        this.allLibelleFr = allLibelleFr;
        this.allLibelleEn = allLibelleEn;
    }

    public Allergene(String allLibelleFr, String allLibelleEn, Collection<Ingredient> ingredients) {
        this.allLibelleFr = allLibelleFr;
        this.allLibelleEn = allLibelleEn;
        this.ingredients = ingredients;
    }

    public String getAllLibelleFr() {
        return allLibelleFr;
    }

    public void setAllLibelleFr(String allLibelleFr) {
        this.allLibelleFr = allLibelleFr;
    }

    public String getAllLibelleEn() {
        return allLibelleEn;
    }

    public void setAllLibelleEn(String allLibelleEn) {
        this.allLibelleEn = allLibelleEn;
    }


    

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Allergene)) {
            return false;
        }
        Allergene other = (Allergene) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Allergene{" + allLibelleFr + ", " + allLibelleEn + ", ingredients : " + ingredients + '}';
    }


    
}
