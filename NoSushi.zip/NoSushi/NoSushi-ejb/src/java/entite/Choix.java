package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Choix implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 80)
    private String optNomFr;
    @Column(nullable = false, length = 80)
    private String optNomEn;
    @Column(nullable = false, length = 80)
    private int optNiveau;
    @Column(nullable = false, length = 80)
    private float optPrix;

    @Column
    private String optPhoto;

    @ManyToMany(mappedBy = "options")
    private Collection<Produit> produits;

    @ManyToMany(mappedBy = "optionslc")
    private Collection<LigneCommande> LigneCommande;

    public Choix() {
        LigneCommande = new ArrayList();
    }

    public Choix(String optNomFr, String optNomEn, int optNiveau, float optPrix) {
        this();
        this.optNomFr = optNomFr;
        this.optNomEn = optNomEn;
        this.optNiveau = optNiveau;
        this.optPrix = optPrix;
    }
    
    

    public Choix(String optNomFr, String optNomEn, int optNiveau, float optPrix, String optPhoto, Collection<LigneCommande> LigneCommande) {
        this();
        this.optNomFr = optNomFr;
        this.optNomEn = optNomEn;
        this.optNiveau = optNiveau;
        this.optPrix = optPrix;
        this.optPhoto = optPhoto;
        this.LigneCommande = LigneCommande;
    }

    public Choix(String optNomFr, String optNomEn, Integer optNiveau, Float optPrix, String optPhoto) {
        this();
        this.optNomFr = optNomFr;
        this.optNomEn = optNomEn;
        this.optNiveau = optNiveau;
        this.optPrix = optPrix;
        this.optPhoto = optPhoto;
    }

    public Choix(String optNomFr, String optNomEn, int optNiveau, float optPrix, String optPhoto, Collection<Produit> Produit, Collection<LigneCommande> LigneCommande) {
        this();
        this.optNomFr = optNomFr;
        this.optNomEn = optNomEn;
        this.optNiveau = optNiveau;
        this.optPrix = optPrix;
        this.optPhoto = optPhoto;
        this.produits = Produit;
        this.LigneCommande = LigneCommande;
    }

    public String getOptNomFr() {
        return optNomFr;
    }

    public void setOptNomFr(String optNomFr) {
        this.optNomFr = optNomFr;
    }

    public String getOptNomEn() {
        return optNomEn;
    }

    public void setOptNomEn(String optNomEn) {
        this.optNomEn = optNomEn;
    }

    public int getOptNiveau() {
        return optNiveau;
    }

    public void setOptNiveau(Integer optNiveau) {
        this.optNiveau = optNiveau;
    }

    public float getOptPrix() {
        return optPrix;
    }

    public void setOptPrix(Float optPrix) {
        this.optPrix = optPrix;
    }

    public String getOptPhoto() {
        return optPhoto;
    }

    public void setOptPhoto(String optPhoto) {
        this.optPhoto = optPhoto;
    }

    public Collection<LigneCommande> getLigneCommande() {
        return LigneCommande;
    }

    public void setLigneCommande(Collection<LigneCommande> LigneCommande) {
        this.LigneCommande = LigneCommande;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }

    @Override
    public String toString() {
        return optNomFr + "[ id=" + id + " ]";
    }

}
