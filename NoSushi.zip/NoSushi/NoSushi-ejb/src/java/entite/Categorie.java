package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Categorie implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column (unique = true, nullable = false, length = 100)
    private String catNomFr;

    @Column (length = 100)
    private String catNomEn;

    @Column (length = 300)
    private String catDescFr;

    @Column (length = 300)
    private String catDescEn;

    @Column (nullable = false, length = 50)
    private String catEtat;

    @Column
    private String catPhoto;
    
    @OneToMany(mappedBy = "categorie")
    private Collection<Produit> produits;
    
    public Categorie() {
        produits = new ArrayList();
    }

    public Categorie(String catNomFr, String catNomEn, String catDescFr, String catDescEn, String catEtat, String catPhoto) {
        this();
        this.catNomFr = catNomFr;
        this.catNomEn = catNomEn;
        this.catDescFr = catDescFr;
        this.catDescEn = catDescEn;
        this.catEtat = catEtat;
        this.catPhoto = catPhoto;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }
    
    public String getCatNomFr() {
        return catNomFr;
    }

    public void setCatNomFr(String catNomFr) {
        this.catNomFr = catNomFr;
    }

    public String getCatNomEn() {
        return catNomEn;
    }

    public void setCatNomEn(String catNomEn) {
        this.catNomEn = catNomEn;
    }

    public String getCatDescFr() {
        return catDescFr;
    }

    public void setCatDescFr(String catDescFr) {
        this.catDescFr = catDescFr;
    }

    public String getCatDescEn() {
        return catDescEn;
    }

    public void setCatDescEn(String catDescEn) {
        this.catDescEn = catDescEn;
    }

    public String getCatEtat() {
        return catEtat;
    }

    public void setCatEtat(String catEtat) {
        this.catEtat = catEtat;
    }

    public String getCatPhoto() {
        return catPhoto;
    }

    public void setCatPhoto(String catPhoto) {
        this.catPhoto = catPhoto;
    }
    
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Categorie)) {
            return false;
        }
        Categorie other = (Categorie) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return catNomFr + "(" + id + " )";
    }
    
}
