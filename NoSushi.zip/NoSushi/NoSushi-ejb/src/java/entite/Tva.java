package entite;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Tva implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column (nullable = false, length = 80)
    private String tvaLibelle;
    
    @Column (nullable = false)
    private float tvaTaux;

    @OneToMany(mappedBy = "Tva")
    private Collection<Produit> produits;
    
     
   
    
    public Tva() {
    }

    public Tva(String tvaLibelle, float tvaTaux) {
        this.tvaLibelle = tvaLibelle;
        this.tvaTaux = tvaTaux;
    }
   public Tva(Long id, String tvaLibelle, float tvaTaux, Collection<Produit> produits) {
        this.id = id;
        this.tvaLibelle = tvaLibelle;
        this.tvaTaux = tvaTaux;
        this.produits = produits;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }
     
   
   
    public String getTvaLibelle() {
        return tvaLibelle;
    }

    public void setTvaLibelle(String tvaLibelle) {
        this.tvaLibelle = tvaLibelle;
    }

    public float getTvaTaux() {
        return tvaTaux;
    }

    public void setTvaTaux(float tvaTaux) {
        this.tvaTaux = tvaTaux;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

   

    
    
    
    
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tva)) {
            return false;
        }
        Tva other = (Tva) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entite.Tva[ id=" + id + " ]";
    }
    
}
