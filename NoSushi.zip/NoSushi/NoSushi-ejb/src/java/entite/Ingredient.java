
package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import javax.persistence.ManyToOne;


@Entity
public class Ingredient implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false, length = 80)
    private String ingNomFr;
    
    @Column(unique = true, nullable = false, length = 80)
    private String ingNomEng;
    
    @ManyToMany(mappedBy = "ingredients")
    private Collection<Produit> produits;

    @Column
    private String ingPhoto;
    
    @ManyToOne
    private Allergene allergene;

    public Ingredient() {
        produits = new ArrayList();
    }

    public Ingredient(String ingNomFr, String ingNomEng, String ingPhoto, Allergene allergene) {
        this();
        this.ingNomFr = ingNomFr;
        this.ingNomEng = ingNomEng;
        this.ingPhoto = ingPhoto;
        this.allergene = allergene;
    }
    
     public Ingredient(String ingNomFr, String ingNomEng, String ingPhoto) {
        this();
        this.ingNomFr = ingNomFr;
        this.ingNomEng = ingNomEng;
        this.ingPhoto = ingPhoto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIngNomFr() {
        return ingNomFr;
    }

    public void setIngNomFr(String ingNomFr) {
        this.ingNomFr = ingNomFr;
    }

    public String getIngNomEng() {
        return ingNomEng;
    }

    public void setIngNomEng(String ingNomEng) {
        this.ingNomEng = ingNomEng;
    }

    public String getIngPhoto() {
        return ingPhoto;
    }

    public void setIngPhoto(String ingPhoto) {
        this.ingPhoto = ingPhoto;
    }

    public Allergene getAllergene() {
        return allergene;
    }

    public void setAllergene(Allergene allergene) {
        this.allergene = allergene;
    }

    public Collection<Produit> getProduits() {
        return produits;
    }

    public void setProduits(Collection<Produit> produits) {
        this.produits = produits;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ingredient)) {
            return false;
        }
        Ingredient other = (Ingredient) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Ingedient (" + id + ")";
    }
    
}
