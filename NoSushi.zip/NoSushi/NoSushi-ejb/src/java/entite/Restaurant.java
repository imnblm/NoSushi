package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Restaurant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column (nullable = false)
    private String restSiren;
    
    @Column
    private String restRS;
    
    @Column
    private String restAdrRue;
    
    @Column
    private String restAdrVille;
    
    @Column
    private String restAdrCp;
    
    @Column
    private String restTel;
    
    @Column
    private String resPortable;
    
    @Column
    private String restMail;
    
    @Column
    private String restWeb;
    
    @Column
    private String restEtat;
    
    @OneToMany(mappedBy = "Restaurant")
    private Collection<Message> messages;
     
    public Restaurant() {
        messages = new ArrayList<>();
    }
    
    public Restaurant(Collection<Message> messages) {
        this ();
    }
    
    public Restaurant(String restSiren, String restRS) {
        this();
        this.restSiren = restSiren;
        this.restRS = restRS;
    }

    public Restaurant(String restSiren, String restRS, String restAdrRue, String restAdrVille, String restAdrCp, String restTel, String resPortable, String restMail, String restWeb, String restEtat, Collection<Message> messages) {
        this();
        this.restSiren = restSiren;
        this.restRS = restRS;
        this.restAdrRue = restAdrRue;
        this.restAdrVille = restAdrVille;
        this.restAdrCp = restAdrCp;
        this.restTel = restTel;
        this.resPortable = resPortable;
        this.restMail = restMail;
        this.restWeb = restWeb;
        this.restEtat = restEtat;
        this.messages = messages;
    }

    public Collection<Message> getMessages() {
        return messages;
    }

    public void setMessages(Collection<Message> messages) {
        this.messages = messages;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRestSiren() {
        return restSiren;
    }

    public void setRestSiren(String restSiren) {
        this.restSiren = restSiren;
    }

    public String getRestRS() {
        return restRS;
    }

    public void setRestRS(String restRS) {
        this.restRS = restRS;
    }

    public String getRestAdrRue() {
        return restAdrRue;
    }

    public void setRestAdrRue(String restAdrRue) {
        this.restAdrRue = restAdrRue;
    }

    public String getRestAdrVille() {
        return restAdrVille;
    }

    public void setRestAdrVille(String restAdrVille) {
        this.restAdrVille = restAdrVille;
    }

    public String getRestAdrCp() {
        return restAdrCp;
    }

    public void setRestAdrCp(String restAdrCp) {
        this.restAdrCp = restAdrCp;
    }

    public String getRestTel() {
        return restTel;
    }

    public void setRestTel(String restTel) {
        this.restTel = restTel;
    }

    public String getResPortable() {
        return resPortable;
    }

    public void setResPortable(String resPortable) {
        this.resPortable = resPortable;
    }

    public String getRestMail() {
        return restMail;
    }

    public void setRestMail(String restMail) {
        this.restMail = restMail;
    }

    public String getRestWeb() {
        return restWeb;
    }

    public void setRestWeb(String restWeb) {
        this.restWeb = restWeb;
    }

    public String getRestEtat() {
        return restEtat;
    }

    public void setRestEtat(String restEtat) {
        this.restEtat = restEtat;
    }
    
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Restaurant)) {
            return false;
        }
        Restaurant other = (Restaurant) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Restaurant{" + "id=" + id + ", restSiren=" + restSiren + ", restRS=" + restRS + ", restAdrRue=" + restAdrRue + ", restAdrVille=" + restAdrVille + ", restAdrCp=" + restAdrCp + ", restTel=" + restTel + ", resPortable=" + resPortable + ", restMail=" + restMail + ", restWeb=" + restWeb + ", restEtat=" + restEtat + ", messages=" + messages + '}';
    }

    
    
}