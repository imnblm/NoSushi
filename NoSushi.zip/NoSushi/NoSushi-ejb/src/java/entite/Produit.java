package entite;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Produit implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column (unique = true, nullable = false, length = 100)
    private String prodNomFr;
    
    @Column (nullable = false, length = 100)
    private String prodNomEn;

    @Column (length = 300)
    private String prodDescFr;
    
    @Column (length = 300)
    private String prodDescEn;

    @Column (nullable = false)
    private float prodPrix;
    
    @Column (nullable = false, length = 50)
    private String prodEtat;
    
    @Column
    private String prodPhoto;
    
    @ManyToOne
    private Categorie categorie;
    
    @ManyToOne
    private Tva Tva;

    @ManyToOne
    private TypeProduit typeProduit;
        
    @ManyToMany
    private Collection<Choix> options;        
    
    @ManyToMany(mappedBy = "produits")
    private Collection<Menu> menus;

    @ManyToMany(mappedBy = "produitscmd")
    private Collection<LigneCommande> lignescmd;
    
    @ManyToMany
    private Collection<Ingredient> ingredients;
    
    @ManyToMany
    private Collection<Caracteristique> caracteristiques;

    public Produit() {
        caracteristiques = new ArrayList();
        ingredients = new ArrayList();
        menus = new ArrayList();
        lignescmd = new ArrayList();
    }

    public Produit(String prodNomFr, String prodNomEn, String prodDescFr, String prodDescEn, float prodPrix, String prodEtat, String prodPhoto, Categorie categorie, Tva Tva, TypeProduit typeProduit, Collection<Choix> Option, Collection<Menu> menus, Collection<LigneCommande> lignescmd) {
        this();
        this.prodNomFr = prodNomFr;
        this.prodNomEn = prodNomEn;
        this.prodDescFr = prodDescFr;
        this.prodDescEn = prodDescEn;
        this.prodPrix = prodPrix;
        this.prodEtat = prodEtat;
        this.prodPhoto = prodPhoto;
        this.categorie = categorie;
        this.Tva = Tva;
        this.typeProduit = typeProduit;
        this.options = Option;
        this.menus = menus;
        this.lignescmd = lignescmd;
    }
    
    public Produit(String prodNomFr, String prodNomEn, String prodDescFr, String prodDescEn, float prodPrix, String prodEtat, String prodPhoto, Categorie categorie) {
        this();
        this.prodNomFr = prodNomFr;
        this.prodNomEn = prodNomEn;
        this.prodDescFr = prodDescFr;
        this.prodDescEn = prodDescEn;
        this.prodPrix = prodPrix;
        this.prodEtat = prodEtat;
        this.prodPhoto = prodPhoto;
        this.categorie = categorie;
    }

    public Produit(String prodNomFr, String prodNomEn, String prodDescFr, String prodDescEn, float prodPrix, String prodEtat, String prodPhoto, Categorie categorie, TypeProduit typeProduit) {
        this();
        this.prodNomFr = prodNomFr;
        this.prodNomEn = prodNomEn;
        this.prodDescFr = prodDescFr;
        this.prodDescEn = prodDescEn;
        this.prodPrix = prodPrix;
        this.prodEtat = prodEtat;
        this.prodPhoto = prodPhoto;
        this.categorie = categorie;
        this.typeProduit = typeProduit;
    }

    public Produit(String prodNomFr, String prodNomEn, String prodDescFr, String prodDescEn, float prodPrix, String prodEtat, String prodPhoto, Categorie categorie, Tva Tva, TypeProduit typeProduit, Collection<Menu> menus, Collection<LigneCommande> lignescmd) {
        this();
        this.prodNomFr = prodNomFr;
        this.prodNomEn = prodNomEn;
        this.prodDescFr = prodDescFr;
        this.prodDescEn = prodDescEn;
        this.prodPrix = prodPrix;
        this.prodEtat = prodEtat;
        this.prodPhoto = prodPhoto;
        this.categorie = categorie;
        this.Tva = Tva;
        this.typeProduit = typeProduit;
        this.menus = menus;
        this.lignescmd = lignescmd;
    }

    public Collection<Choix> getOptions() {
        return options;
    }

    public void setOptions(Collection<Choix> options) {
        this.options = options;
    }

    public Tva getTva() {
        return Tva;
    }

    public void setTva(Tva Tva) {
        this.Tva = Tva;
    }

    public Collection<LigneCommande> getLignescmd() {
        return lignescmd;
    }

    public void setLignescmd(Collection<LigneCommande> lignescmd) {
        this.lignescmd = lignescmd;
    }

    public Categorie getCategorie() {
        return categorie;
    }

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
    }
    
    public TypeProduit getTypeProduit() {
        return typeProduit;
    }

    public void setTypeProduit(TypeProduit typeProduit) {
        this.typeProduit = typeProduit;
    }

    public Collection<Menu> getMenus() {
        return menus;
    }

    public void setMenus(Collection<Menu> menus) {
        this.menus = menus;
    }

    public String getProdNomFr() {
        return prodNomFr;
    }

    public void setProdNomFr(String prodNomFr) {
        this.prodNomFr = prodNomFr;
    }

    public String getProdNomEn() {
        return prodNomEn;
    }

    public void setProdNomEn(String prodNomEn) {
        this.prodNomEn = prodNomEn;
    }

    public String getProdDescFr() {
        return prodDescFr;
    }

    public void setProdDescFr(String prodDescFr) {
        this.prodDescFr = prodDescFr;
    }

    public String getProdDescEn() {
        return prodDescEn;
    }

    public void setProdDescEn(String prodDescEn) {
        this.prodDescEn = prodDescEn;
    }

    public float getProdPrix() {
        return prodPrix;
    }

    public void setProdPrix(float prodPrix) {
        this.prodPrix = prodPrix;
    }

    public String getProdEtat() {
        return prodEtat;
    }

    public void setProdEtat(String prodEtat) {
        this.prodEtat = prodEtat;
    }

    public String getProdPhoto() {
        return prodPhoto;
    }

    public void setProdPhoto(String prodPhoto) {
        this.prodPhoto = prodPhoto;
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Produit)) {
            return false;
        }
        Produit other = (Produit) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    public Collection<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(Collection<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public Collection<Caracteristique> getCaracteristiques() {
        return caracteristiques;
    }

    public void setCaracteristiques(Collection<Caracteristique> caracteristiques) {
        this.caracteristiques = caracteristiques;
    }

    @Override
    public String toString() {
        return prodNomFr + "(id)";
    }
}
