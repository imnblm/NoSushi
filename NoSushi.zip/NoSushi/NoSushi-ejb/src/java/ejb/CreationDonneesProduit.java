package ejb;

import entite.Allergene;
import entite.Caracteristique;
import entite.Categorie;
import entite.Client;
import entite.Commande;
import entite.Ingredient;
import entite.LigneCommande;
import entite.Menu;
import entite.Message;
import entite.Choix;
import entite.Paiement;
import entite.Produit;
import entite.Restaurant;
import entite.Tva;
import entite.TypeProduit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class CreationDonneesProduit implements CreationDonneesProduitLocal {

    @PersistenceContext(unitName = "NoSushi-ejbPU")
    private EntityManager em;

    @Override
    public void CreationDonneesProduit() {

        // Création des menus
        Menu m01 = new Menu("GYOZA SET", "", "10 pièces de raviolis frits au porc accompagnés de bouillon, salade, riz, légumes salés", "10 pcs of pork and vegetables fried dumplings with salad, rice, broth, pickles", 12.00f);
        Menu m02 = new Menu("SHUMAI SET", "", "10 pièces de raviolis vapeur au porc et crevettes accompagnés de bouillon, salade, riz, légumes salés", "10 pcs of pork and shrimp steamed dimsum with salad, rice, broth, pickles", 12.00f);
        Menu m03 = new Menu("GYOZA + SHUMAI SET", "", "5 pièces de raviolis frits et 5 pièces de raviolis vapeur accompagnés de bouillon ,salade, riz, légumes salés", "5 pcs of pork raviolis and 5 pcs of pork dimsum with salad, rice, broth, pickles", 12.00f);

        em.persist(m01);
        em.persist(m02);
        em.persist(m03);
        em.flush();

        // Création des type de produits
        TypeProduit tp01 = new TypeProduit("ACCOMPAGNEMENT");
        TypeProduit tp02 = new TypeProduit("PLATS");
        TypeProduit tp03 = new TypeProduit("DESSERT");
        TypeProduit tp04 = new TypeProduit("BOISSON");

        em.persist(tp01);
        em.persist(tp02);
        em.persist(tp03);
        em.persist(tp04);
        em.flush();

        // Création des catégories
        Categorie cat01 = new Categorie("ACCOMPAGNEMENT CHAUD", "HOT SIDE DISHES", "", "", "ACTIF", "");
        Categorie cat02 = new Categorie("ACCOMPAGNEMENT FROID", "COLD SIDE DISHES", "", "", "ACTIF", "");
        Categorie cat03 = new Categorie("GARNITURES", "TOPPING SUPPLEMENTS", "", "", "ACTIF", "");
        Categorie cat04 = new Categorie("RAMEN", "", "", "", "ACTIF", "");
        Categorie cat05 = new Categorie("PLATS SAUTÉS", "WOK SAUTED DISHES", "", "", "ACTIF", "");
        Categorie cat06 = new Categorie("AUTRES PLATS SAUTÉS", "OTHER WOK SAUTED DISHES", "", "", "ACTIF", "");
        Categorie cat07 = new Categorie("POISSONS GRILLÉS", "GRILLED FISHES", "", "", "ACTIF", "");
        Categorie cat08 = new Categorie("UDON OU SOBA", "", "", "", "ACTIF", "");
        Categorie cat09 = new Categorie("DONMONO", "", "", "", "ACTIF", "");
        Categorie cat10 = new Categorie("CURRY", "", "", "", "ACTIF", "");
        Categorie cat11 = new Categorie("FRITURES", "", "", "", "ACTIF", "");
        Categorie cat12 = new Categorie("DESSERTS", "", "", "", "ACTIF", "");
        Categorie cat13 = new Categorie("BOISSONS", "", "", "", "ACTIF", "");
        Categorie cat14 = new Categorie("BOISSONS CHAUDES", "", "", "", "ACTIF", "");
        Categorie cat15 = new Categorie("BOISSONS ALCOOL", "", "", "", "ACTIF", "");
        Categorie cat16 = new Categorie("BOISSONS VINS", "", "", "", "ACTIF", "");
        Categorie cat17 = new Categorie("BOISSONS BIERE", "", "", "", "ACTIF", "");

        em.persist(cat01);
        em.persist(cat02);
        em.persist(cat03);
        em.persist(cat04);
        em.persist(cat05);
        em.persist(cat06);
        em.persist(cat07);
        em.persist(cat08);
        em.persist(cat09);
        em.persist(cat10);
        em.persist(cat11);
        em.persist(cat12);
        em.persist(cat13);
        em.persist(cat14);
        em.persist(cat15);
        em.persist(cat16);
        em.persist(cat17);

        em.flush();

        // Création des produits
        Produit p001 = new Produit("Miso ramen", "", "Ramen au miso et porc haché ", "Ramen in a miso flavoured broth", (float) 9.5, "ACTIF", "MisoRamen01.jpg", cat04, tp02);
        Produit p002 = new Produit("Chashu ramen", "", "Shoyu Ramen avec tranches de porc", "Shoyu ramen with sliced pork", (float) 9.5, "ACTIF", "ChashuRamen01.jpg", cat04, tp02);
        Produit p003 = new Produit("Negi ramen", "", "Shoyu ramen avec poireaux", "Shoyu ramen with leeks", (float) 9.5, "ACTIF", "NegiRamen01.jpg", cat04, tp02);
        Produit p004 = new Produit("Shio ramen", "", "Ramen à base de sel", "Ramen in a salty flavoured broth", (float) 6.5, "ACTIF", "ShioRamen01.jpg", cat04, tp02);
        Produit p005 = new Produit("Tanmen", "", "Shio ramen aux légumes", "Shio ramen with vegetables", (float) 9.5, "ACTIF", "Tanmen01.jpg", cat04, tp02);
        Produit p006 = new Produit("Kimuchi ramen", "", "Shio ramen aux choux pimentés et porc", "Shio ramen with spicy cabbages and pork", (float) 9.5, "ACTIF", "KimuchiRamen01.jpg", cat04, tp02);
        Produit p007 = new Produit("Shoyu ramen", "", "Ramen à base de sauce soja", "Ramen in soy flavoured broth", (float) 9.5, "ACTIF", "ShoyuRamen01", cat04, tp02);
        Produit p008 = new Produit("Curry ramen", "", "Shoyu ramen au curry et bœuf", "Shoyu ramen with beef curry", (float) 9.5, "ACTIF", "CurryRamen01", cat04, tp02);
        Produit p009 = new Produit("Mabo ramen", "", "Shoyu ramen au tofu et porc haché", "Shoyu ramen with tofu and minced pork", (float) 10, "ACTIF", "MaboRamen01.jpg", cat04, tp02);
        Produit p010 = new Produit("Gekikara ramen", "", "Shio ramen piquant au porc haché", "Spicy shio ramen with minced pork", (float) 9.5, "ACTIF", "GekikaraRamen01.jpg", cat04, tp02);
        Produit p011 = new Produit("Butter Corn ramen", "", "Shio ramen avec beurre et maïs", "Shio ramen with butter and corn", (float) 9.5, "ACTIF", "ButterCornRamen01", cat04, tp02);
        Produit p012 = new Produit("Chanpon ramen", "", "Shio ramen au porc, calamars et légumes sautés", "Shio ramen with pork, squid  and vegetables cooked in a wok", (float) 10, "ACTIF", "ChamponRamen01.jpg", cat04, tp02);
        Produit p013 = new Produit("Kake udon / soba", "", "Soupe de pâtes simple", "Simple noodles soup", (float) 8.5, "ACTIF", "KakeUdon01.jpg", cat08, tp02);
        Produit p014 = new Produit("Tanuki udon / soba", "", "Soupe de pâtes avec chapelure frites", "Noodles soup with breadcrumbs", (float) 9.5, "ACTIF", "TanukiUdon01", cat08, tp02);
        Produit p015 = new Produit("Tsukime udon / soba", "", "Soupe de pâtes avec œuf cru", "Noodles soup with raw egg", (float) 9.5, "ACTIF", "TsukimeUdon01.jpg", cat08, tp02);
        Produit p016 = new Produit("Curry udon / soba", "", "Soupe de pâtes au curry avec poulet", "Noodles soup with chicken curry", (float) 11, "ACTIF", "CurryUdon01.jpg", cat08, tp02);
        Produit p017 = new Produit("Nameko udon / soba", "", "Soupe de pâtes, champignon,  nameko et radis râpé", "Noodles soup , nameko mushroom", (float) 11, "ACTIF", "NamekoUdon01.jpg", cat08, tp02);
        Produit p018 = new Produit("Kastuni udon / soba", "", "Soupe de pâtes recouverte d'omelette au porc pané", "Noodles soup topped with fried pork scrambled egg", (float) 11.5, "ACTIF", "KastuniUdon01.jpg", cat08, tp02);
        Produit p019 = new Produit("Tempura udon / soba", "", "Soupe de pâtes avec 2 pcs de crevettes pânées", "Noodles soup with 2 pcs of fried shrimps", (float) 12.5, "ACTIF", "TempuraUdon01.jpg", cat08, tp02);
        Produit p020 = new Produit("Nameko zaru udon / soba", "", "Pâtes froides avec champignon nameko et radis rapé", "Cold noodles with sweet soy sauce and nameko mushroom", (float) 11, "ACTIF", "NamekoZaruUdon01.jpg", cat08, tp02);
        Produit p021 = new Produit("Kitsune udon /soba", "", "Soupe de pâtes avec tofu frit sucré", "Noodles soup with sweet fried tofu", (float) 9.5, "ACTIF", "KitsuneUdon01.jpg", cat08, tp02);
        Produit p022 = new Produit("Wakame udon / soba", "", "Soupe de pâtes avec algues", "Noodles soup with seaweed", (float) 9.5, "ACTIF", "WakameUdon01.jpg", cat08, tp02);
        Produit p023 = new Produit("Kimura udon /soba", "", "Soupe de pates avec choux piquants", "Noodles soup with spicy cabbages", (float) 9.5, "ACTIF", "KimuraUdon01.jpg", cat08, tp02);
        Produit p024 = new Produit("Kamonegi udon / soba", "", "Soupe de pâtes avec magret de canard et poireaux", "Noodles soup with sliced duck and leek", (float) 11, "ACTIF", "KamonegiUdon01.jpg", cat08, tp02);
        Produit p025 = new Produit("Oyako udon / soba", "", "Soupe de pâtes recouverte d'omelette au poulet", "Noodles soup with chicken scrambled egg", (float) 11, "ACTIF", "OyakodonUdon01.jpg", cat08, tp02);
        Produit p026 = new Produit("Gyuniku udon / soba", "", "Soupe de pâtes au bœuf au soja sucré", "Noodles soup with beef in a sweet soy sauce", (float) 11.5, "ACTIF", "GyunikuUdon01.jpg", cat08, tp02);
        Produit p027 = new Produit("Zaru udon / soba", "", "Pâtes froides et sa sauce soja sucrée / salée", "Cold noodles with sweet soy sauce", (float) 8.5, "ACTIF", "ZaruUdon01.jpg", cat08, tp02);
        Produit p028 = new Produit("Nabeyaki udon", "", "Marmite de pâtes udon avec crevette panée, œuf, légumes, poulet", "Noodles soup with fried shrimp, egg, vegetables, chicken", (float) 13.5, "ACTIF", "NabeyakiUdon01.jpg", cat08, tp02);
        Produit p029 = new Produit("Yakisoba", "", "Nouilles sautées à la sauce soja avec calamars, porc et légumes", "Noodles cooked in sweet soysauce with pork, squid, vegetables", (float) 9, "ACTIF", "Yakisoba01.jpg", cat05, tp02);
        Produit p030 = new Produit("Gomuku yakisoba", "", "Nouilles croquantes recouvertes de légumes,calamars et porc sautés au wok", "Fried noodles covered by pork, vegetables and squids in a wok", (float) 9, "ACTIF", "GomokuYakisoba01.jpg", cat05, tp02);
        Produit p031 = new Produit("Curry chahan", "", "Riz sauté au curry au porc et crevettes", "Cantonese style rice with curry spice", (float) 9, "ACTIF", "CurryChahan01.jpg", cat05, tp02);
        Produit p032 = new Produit("Mabodon", "", "Riz recouvert de tofu, porc haché sautés à la sauce soja pimentée", "Rice topped with tofu and minced pork cooked in a wok with spicy sauce", (float) 9.5, "ACTIF", "Mabodon01.jpg", cat05, tp02);
        Produit p033 = new Produit("Yaki udon", "", "Nouilles épaisses sautées avec bœuf, légumes", "Noodles cooked with beef and vegetables", (float) 9, "ACTIF", "YakiUdon01.jpg", cat05, tp02);
        Produit p034 = new Produit("Chahan", "", "Riz sauté au porc et crevettes", "Cantonese style rice with pork and shrimp", (float) 9, "ACTIF", "Chahan01.jpg", cat05, tp02);
        Produit p035 = new Produit("Chukadon", "", "Riz recouvert de légumes, porc, calamars sautés au wok", "Rice topped with vegetables and pork and squids cooked in a wok", (float) 9.5, "ACTIF", "Chukadon01.jpg", cat05, tp02);
        Produit p036 = new Produit("Bœuf Shangai", "", "Bœuf sauté avec choux Shangai", "Sauté of beef with Shangai's cabbage", (float) 9.5, "ACTIF", "BoeufShangai01.jpg", cat06, tp02);
        Produit p037 = new Produit("Nikuyasai", "", "Porc sauté avec légumes", "Sauté of pork with vegetables", (float) 9, "ACTIF", "Nikuyasai01.jpg", cat06, tp02);
        Produit p038 = new Produit("Yakiniku", "", "Bœuf sauté sauce yakiniku ", "Sauté of beef with yakiniky sauce", (float) 11.5, "ACTIF", "Yakiniku01.jpg", cat06, tp02);
        Produit p039 = new Produit("Porc Shangai", "", "Porc sauté avec choux Shangai", "Sauté of pork with Shangai's cabbage", (float) 9.5, "ACTIF", "PorcShangai01.jpg", cat06, tp02);
        Produit p040 = new Produit("Niraleba", "", "Foie de bœuf sauté avec légumes", "Sauté of beef lever with vegetables", (float) 9.5, "ACTIF", "Niraleba01.jpg", cat06, tp02);
        Produit p041 = new Produit("Butashoga yaki", "", "Porc sauté au gingembre", "Sauté of pork with ginger", (float) 11.5, "ACTIF", "ButashogaYaku01.jpg", cat06, tp02);
        Produit p042 = new Produit("Gyoza", "", "5 pcs de raviolis frits au porc et aux légumes", "Pork and vegetables fried dumpling", (float) 4.5, "ACTIF", "Gyoza01.jpg", cat01, tp01);
        Produit p042b = new Produit("Gyoza set", "", "10 pcs de raviolis frits au porc et aux légumes", "Pork and vegetables fried dumpling", (float) 0, "ACTIF", "Gyoza02.jpg", null, null);
        Produit p043 = new Produit("1/2 Chahan", "", "Riz sauté au porc, crevettes", "Japanese style cantonese rice with pork and shrimp", (float) 5, "ACTIF", "Chahan01.jpg", cat01, tp01);
        Produit p044 = new Produit("Shumai", "10 Raviolis cuits à la vapeur au porc, crevettes, légumes", "", "Pork and shrimp steamed dimsum", (float) 4.5, "ACTIF", "Shumai01.jpg", cat01, tp01);
        Produit p044b = new Produit("Shumai set", "Raviolis cuits à la vapeur au porc, crevettes, légumes", "", "Pork and shrimp steamed dimsum", (float) 0, "ACTIF", "Shumai01.jpg", null, null);
        Produit p045 = new Produit("1/2 torikara", "", "Poulet pané à la kintaro", "Kintaro style fried chicken", (float) 6, "ACTIF", "Torikara01.jpg", cat01, tp01);
        Produit p046 = new Produit("Ochazuke Kombu", "", "Riz avec algues marinées dans un bouillon à base sauce soja", "Rice ball with seaweed in a soy sauce based broth", (float) 6, "ACTIF", "OchazukeKombu01.jpg", cat01, tp01);
        Produit p047 = new Produit("Ochazuke Ume", "", "Riz avec prune salée dans un bouillon a base de sauce soja", "Rice ball in soy sauce based broth of salmon", (float) 6, "ACTIF", "OchazukeUme01.jpg", cat01);
        Produit p048 = new Produit("Riz blanc", "", "", "White rice", (float) 2, "ACTIF", "RizBlanc01.jpg", cat01, tp01);
        Produit p049 = new Produit("Soupe miso ou Bouillon", "", "", "Miso soup or broth", (float) 2, "ACTIF", "SoupeMiso01.jpg", cat01, tp01);
        Produit p050 = new Produit("Edamame", "", "Pois mange-tout japonais", "Soybeans in pods", (float) 3, "ACTIF", "Edamane01.jpg", cat02, tp01);
        Produit p051 = new Produit("Kimuchi", "", "Choux chinois mariné piquant", "Spicy marinated cabbage", (float) 3.5, "ACTIF", "Kimuchi01.jpg", cat02, tp01);
        Produit p052 = new Produit("Racine de lotus mariné", "", "", "Marinated lotus roots", (float) 3, "ACTIF", "RacineLotusMarine01.jpg", cat02, tp01);
        Produit p053 = new Produit("Chrysanthème", "", "", "Edible chrysanthemum", (float) 3, "ACTIF", "Chrysantheme01.jpg", cat02, tp01);
        Produit p054 = new Produit("Natto", "", "Soja fermenté", "Fermented soybeans", (float) 5, "ACTIF", "Natto01.jpg", cat02, tp01);
        Produit p055 = new Produit("Tsukemono", "", "Choux chinois mariné maison", "Japanese style marinated cabbage", (float) 3.5, "ACTIF", "Tsukemono01.jpg", cat02, tp01);
        Produit p056 = new Produit("Inari (2 pcs)", "", "Riz vinaigré enveloppé dans tofu frit sucré", "Sushi rice wrapped in fried tofu", (float) 5, "ACTIF", "Inari01.jpg", cat02, tp01);
        Produit p057 = new Produit("Onigiri", "", "Riz enveloppé dans feuille d'algue. Au choix : Saumon, Bonite, Algues marinées, Prune", "Riceball covered by seaweed. Flavor : salmon, bonito, seaweed or plum", (float) 9.5, "ACTIF", "Onigiri01.jpg", cat02, tp01);
        Produit p058 = new Produit("Petite salade", "", "", "Salad", (float) 3, "ACTIF", "PetiteSalade01.jpg", cat02, tp01);
        Produit p059 = new Produit("Saumon grillé", "", "Filet de saumon grillé", "Grilled salmon filet", (float) 11.5, "ACTIF", "SaumonGrille01.jpg", cat07, tp02);
        Produit p060 = new Produit("Maquereau grillé", "", "Filet de maquereau grillé", "Grilled mackerel filet", (float) 13, "ACTIF", "MaquereauGrille01.jpg", cat07, tp02);
        Produit p061 = new Produit("Tamagodon", "", "Omelette à la ciboulette sur lit de riz avec sauce soja sucrée", "Rice topped with scrambled egg and chives with sweet soy sauce", (float) 10, "ACTIF", "Tamagodon01.jpg", cat09, tp02);
        Produit p062 = new Produit("Toridon", "", "Poulet caramélisé sur lit de riz", "Rice topped with chicken and sweet caramelized soy sauce", (float) 10, "ACTIF", "Toridon01.jpg", cat09, tp02);
        Produit p063 = new Produit("Gyudon", "", "Omelette au bœuf sur lit de riz avec sauce soja sucrée", "Rice topped with egg and beef with sweet soy sauce", (float) 10.5, "ACTIF", "Gyudon01.jpg", cat09, tp02);
        Produit p064 = new Produit("Tendon", "", "Crevettes et légumes panés surt lit de riz avec sauce soja sucrée", "Rice topped with shrimps and vegetables tempura with sweet soy sauce", (float) 12.5, "ACTIF", "Tendon01.jpg", cat09, tp02);
        Produit p065 = new Produit("Oyakodon", "", "Omelette au poulet sur lit de riz avec sauce soja sucrée", "Rice topped with scrambled egg and chicken with sweet soy sauce", (float) 10, "ACTIF", "Oyakodon01.jpg", cat09, tp02);
        Produit p066 = new Produit("Kastudon", "", "Omelette au porc pané sur lit de riz avec sauce soja sucrée", "Rice covered with scrambled egg and Fried pork filet with sweet soy sauce", (float) 10, "ACTIF", "Katsudon01.jpg", cat09, tp02);
        Produit p067 = new Produit("Nattodon", "", "Soja fermenté, pousse bamabou et œuf cru sur lit de riz", "", (float) 10.5, "ACTIF", "Nattodon01.jpg", cat09, tp02);
        Produit p068 = new Produit("Unadon", "", "Filet d'anguille caramélisé sur lit de riz", "Rice topped with eel in sweet soy sauce", (float) 16.5, "ACTIF", "Unadon01.jpg", cat09, tp02);
        Produit p069 = new Produit("Chicken curry", "", "Curry au poulet", "", (float) 9.5, "ACTIF", "ChickenCurry01.jpg", cat10, tp02);
        Produit p070 = new Produit("Spicy beef curry", "", "Curry piquant au poulet", "", (float) 9.5, "ACTIF", "SpicyBeefCurry01.jpg", cat09, tp02);
        Produit p071 = new Produit("Tamago curry", "", "Curry  au bœuf avec œuf", "Beef curry with egg", (float) 10, "ACTIF", "TamagoCurry01.jpg", cat09, tp02);
        Produit p072 = new Produit("Ebi furai curry", "", "Curry avec crevettes panées", "Curry with breaded shrimps", (float) 12, "ACTIF", "EbiFuraiCurry01.jpg", cat09, tp02);
        Produit p073 = new Produit("Beef curry", "", "Curry au bœuf ", "", (float) 9.5, "ACTIF", "BeefCurry01.jpg", cat09, tp02);
        Produit p074 = new Produit("Butter corn curry", "", "Curry avec beurre et maïs", "Curry with butter and corn", (float) 9.5, "ACTIF", "ButterCornCurry01", cat09, tp02);
        Produit p075 = new Produit("Katsu curry", "", "Curry avec porc ou poulet pané", "Curry with breded pork or chicken", (float) 10.5, "ACTIF", "KatsuCurry01.jpg", cat09, tp02);
        Produit p076 = new Produit("Chicken kastu", "", "Poulet pané", "Deep-fried and breaded chicken", (float) 10.5, "ACTIF", "ChickenKatsu01.jpg", cat09, tp02);
        Produit p077 = new Produit("Torikara", "", "Poulet pané à la kintaro", "Kintaro style fried chicken", (float) 10.5, "ACTIF", "Torikara01.jpg", cat09, tp02);
        Produit p078 = new Produit("Ebi furai", "", "Crevettes panées", "Deep-fried and breaded shrimps", (float) 10.5, "ACTIF", "EbiFurai01.jpg", cat09, tp02);
        Produit p079 = new Produit("Tonkastu", "", "Porc pané", "Deep-fried and breaded pork", (float) 10.5, "ACTIF", "Tonkatsu01.jpg", cat09, tp02);
        Produit p080 = new Produit("Korokke", "", "Panés de légumes  et pommes de terreDeep-fried and breaded potatoes and vegetables", "Deep-fried and breaded potatoes and vegetables", (float) 10.5, "ACTIF", "Korokke01.jpg", cat09, tp02);
        Produit p081 = new Produit("Cake au thé vert", "", "Quatre quart au thé vert fourré au haricot rouge", "Matcha cake with red bean paste", (float) 5.5, "ACTIF", "CakeTheVert01.jpg", cat12, tp03);
        Produit p082 = new Produit("Glace thé vert ou sésame", "", "2 boules de glace au choix", "2 scoops of matcha ou black sesame ice cream", (float) 5, "ACTIF", "GlaceTheVert01.jpg", cat12, tp03);
        Produit p083 = new Produit("Flan thé vert ou sésame noir", "", "Flan au thé vert ou sésame noir", "Matcha or black sesame custard", (float) 5.5, "ACTIF", "FlanTheVert01.jpg", cat12, tp03);
        Produit p084 = new Produit("Yukimi daifuku (thé vert ou sésame noir)", "", "Glace au thé vert ou sésame enrobée de pâte de riz gluant", "Mochi (pounded sticky rice) filled with match o black sesame ice cream", (float) 4.5, "ACTIF", "YukimiDaifuku01.jpg", cat12, tp03);
        Produit p085 = new Produit("Gelée de café", "", "Gelée au café , sucre noir d'Okinawa ", "Coffee jelly with black sur of Okinawa", (float) 5, "ACTIF", "GeleeCafe01.jpg", cat12, tp03);
        Produit p086 = new Produit("Cheesecake", "", "Cheesecake à la japonaise", "Japanese style cheesecake", (float) 5.5, "ACTIF", "Cheesecake01.jpg", cat12, tp03);
        Produit p087 = new Produit("Thé vert froid", "", "33 cl", "", (float) 3.5, "ACTIF", "TheVertFroid01.jpg", cat13, tp04);
        Produit p088 = new Produit("Thé Oolong froid", "", "33 cl", "", (float) 3.5, "ACTIF", "TheOolonFroid01.jpg", cat13, tp04);
        Produit p089 = new Produit("Coca cola", "", "33 cl", "", (float) 3, "ACTIF", "CocaCola01.jpg", cat13, tp04);
        Produit p090 = new Produit("Jus d'orange", "", "20 cl", "", (float) 3.5, "ACTIF", "JusOrange01.jpg", cat13, tp04);
        Produit p091 = new Produit("Calpis", "", "25 cl", "", (float) 3, "ACTIF", "Calpi01.jpg", cat13, tp04);
        Produit p092 = new Produit("Evian", "", "50 cl", "", (float) 3, "ACTIF", "Evian01.jpg", cat13, tp04);
        Produit p093 = new Produit("Badoit", "", "50 cl", "", (float) 4, "ACTIF", "Badoit01.jpg", cat13, tp04);
        Produit p094 = new Produit("Café", "", "", "", (float) 2, "ACTIF", "Cafe01.jpg", cat14, tp04);
        Produit p095 = new Produit("Thé vert chaud", "", "20 cl", "", (float) 2, "ACTIF", "TheVertChaud01.jpg", cat14, tp04);
        Produit p096 = new Produit("Thé genmai", "", "à base de riz soufflé", "", (float) 2, "ACTIF", "TheGenmai01.jpg", cat14, tp04);
        Produit p097 = new Produit("Saké japonais (chaud ou froid)", "14 cl", "", "", (float) 6, "ACTIF", "SakeJaponais01.jpg", cat15, tp04);
        Produit p098 = new Produit("Umeshu (Liqueur de prune)", "", "7 cl", "", (float) 5, "ACTIF", "Umeshu01.jpg", cat15, tp04);
        Produit p099 = new Produit("Vin rouge - verre", "", "Côtes du Rhône, Cuvée Guillaume II, 2015", "Red wine", (float) 4.5, "ACTIF", "VinRouge03.jpg", cat16, tp04);
        Produit p100 = new Produit("Vin rouge - bouteille", "", "Côtes du Rhône, Cuvée Guillaume II, 2015", "Red wine", (float) 24, "ACTIF", "VinRouge03.jpg", cat16, tp04);
        Produit p101 = new Produit("Vin blanc - verre", "", "Lancerre, Domaine Auchère 2016", "White wine", (float) 4.5, "ACTIF", "VinBlanc01.jpg", cat16, tp04);
        Produit p102 = new Produit("Vin blanc - bouteille", "", "Lancerre, Domaine Auchère 2016", "White wine", (float) 24, "ACTIF", "VinBlanc01.jpg", cat16, tp04);
        Produit p103 = new Produit("Kirin pression 25 cl", "", "", "", (float) 3.5, "ACTIF", "KirinPression01.jpg", cat17, tp04);
        Produit p104 = new Produit("Kirin pression 50 cl", "", "", "", (float) 6, "ACTIF", "KirinPression01.jpg", cat17, tp04);
        Produit p105 = new Produit("Bière artisanale", "", "33 cl", "", (float) 6.5, "ACTIF", "BiereArtisanale01.jpg", cat17, tp04);
        Produit p106 = new Produit("Pickles", "", "", "", (float) 0, "ACTIF", "Pickles01.jpg", null, null);

        em.persist(p001);
        em.persist(p002);
        em.persist(p003);
        em.persist(p004);
        em.persist(p005);
        em.persist(p006);
        em.persist(p007);
        em.persist(p008);
        em.persist(p009);
        em.persist(p010);
        em.persist(p011);
        em.persist(p012);
        em.persist(p013);
        em.persist(p014);
        em.persist(p015);
        em.persist(p016);
        em.persist(p017);
        em.persist(p018);
        em.persist(p019);
        em.persist(p020);
        em.persist(p021);
        em.persist(p022);
        em.persist(p023);
        em.persist(p024);
        em.persist(p025);
        em.persist(p026);
        em.persist(p027);
        em.persist(p028);
        em.persist(p029);
        em.persist(p030);
        em.persist(p031);
        em.persist(p032);
        em.persist(p033);
        em.persist(p034);
        em.persist(p035);
        em.persist(p036);
        em.persist(p037);
        em.persist(p038);
        em.persist(p039);
        em.persist(p040);
        em.persist(p041);
        em.persist(p042);
        em.persist(p042b);
        em.persist(p043);
        em.persist(p044);
        em.persist(p044b);
        em.persist(p045);
        em.persist(p046);
        em.persist(p047);
        em.persist(p048);
        em.persist(p049);
        em.persist(p050);
        em.persist(p051);
        em.persist(p052);
        em.persist(p053);
        em.persist(p054);
        em.persist(p055);
        em.persist(p056);
        em.persist(p057);
        em.persist(p058);
        em.persist(p059);
        em.persist(p060);
        em.persist(p061);
        em.persist(p062);
        em.persist(p063);
        em.persist(p064);
        em.persist(p065);
        em.persist(p066);
        em.persist(p067);
        em.persist(p068);
        em.persist(p069);
        em.persist(p070);
        em.persist(p071);
        em.persist(p072);
        em.persist(p073);
        em.persist(p074);
        em.persist(p075);
        em.persist(p076);
        em.persist(p077);
        em.persist(p078);
        em.persist(p079);
        em.persist(p080);
        em.persist(p081);
        em.persist(p082);
        em.persist(p083);
        em.persist(p084);
        em.persist(p085);
        em.persist(p086);
        em.persist(p087);
        em.persist(p088);
        em.persist(p089);
        em.persist(p090);
        em.persist(p091);
        em.persist(p092);
        em.persist(p093);
        em.persist(p094);
        em.persist(p095);
        em.persist(p096);
        em.persist(p097);
        em.persist(p098);
        em.persist(p099);
        em.persist(p100);
        em.persist(p101);
        em.persist(p102);
        em.persist(p103);
        em.persist(p104);
        em.persist(p105);
        em.persist(p106);

        em.flush();

        // Création plats/menus
        Collection<Produit> produits = m01.getProduits();
        produits.add(p049);
        produits.add(p058);
        produits.add(p048);
        produits.add(p106);
        produits.add(p042b);

        produits = m02.getProduits();
        produits.add(p049);
        produits.add(p058);
        produits.add(p048);
        produits.add(p106);
        produits.add(p044b);

        produits = m03.getProduits();
        produits.add(p049);
        produits.add(p058);
        produits.add(p048);
        produits.add(p106);
        produits.add(p042);
        produits.add(p044);
        
        //Création des caracteristiques
        Caracteristique car01 = new Caracteristique("Contenance", "25", "cl");
        Caracteristique car02 = new Caracteristique("Contenance", "50", "cl");
        Caracteristique car03 = new Caracteristique("Contenance", "33", "cl");
        Caracteristique car04 = new Caracteristique("Contenance", "20", "cl");
        
        em.persist(car01);
        em.persist(car02);
        em.persist(car03);
        em.persist(car04);
        
        em.flush();
        
         //Création lien caracteristique produit

        Collection<Caracteristique> caracts = p103.getCaracteristiques();
        caracts.add(car01);
        
        Collection<Caracteristique> caracts02 = p104.getCaracteristiques();
        caracts02.add(car02);
        
        Collection<Caracteristique> caracts03 = p105.getCaracteristiques();
        caracts03.add(car03);
        
        Collection<Caracteristique> caracts04 = p090.getCaracteristiques();
        caracts04.add(car04);


        // creation allergenes 
        Allergene a01 = new Allergene("Céréales contenant du gluten","Cereals containing gluten");
        Allergene a02 = new Allergene("Crustacés","Shellfish");
        Allergene a03 = new Allergene("Oeufs","Eggs");
        Allergene a04 = new Allergene("Poissons","Fishes");
        Allergene a05 = new Allergene("Arachides","Peanuts");
        Allergene a06 = new Allergene("Soja","Soy");
        Allergene a07 = new Allergene("Lait","Milk");
        Allergene a08 = new Allergene("Fruits à coque","Nuts");
        Allergene a09 = new Allergene("Moutarde","Mustard");
        Allergene a10 = new Allergene("Céleri","Celery");
        Allergene a11 = new Allergene("Graines de sésame","Sesame seeds");
        Allergene a12 = new Allergene("Anhydride sulfureux et sulfites en concentration de plus de 10mg/kg ou 10 mg/l",
                "Sulfur dioxide and sulphites in concentrations of more than 10 mg / kg or 10 mg / l");
        Allergene a13 = new Allergene("Lupin","Lupine");
        Allergene a14 = new Allergene("Mollusques","Mollusc");

        em.persist(a01);
        em.persist(a02);
        em.persist(a03);
        em.persist(a04);
        em.persist(a05);
        em.persist(a06);
        em.persist(a07);
        em.persist(a08);
        em.persist(a09);
        em.persist(a10);
        em.persist(a11);
        em.persist(a12);
        em.persist(a13);
        em.persist(a14);
        em.flush();

// Creation Ingredients 
        //viandes
        Ingredient i01 = new Ingredient("Poulet", "Chicken", "");
        Ingredient i02 = new Ingredient("Porc", "Pork", "");
        Ingredient i03 = new Ingredient("Boeuf", "Beef", "");
        Ingredient i10 = new Ingredient("Canard", "Duck", "");
        Ingredient i20 = new Ingredient("Omelette", "Scambled egg", "", a03);
        Ingredient i21 = new Ingredient("Oeuf", "Egg", "", a03);
        // poissons + crustacés
        Ingredient i04 = new Ingredient("Saumon", "Salmon", "", a04);
        Ingredient i05 = new Ingredient("Maquereau", "Mackerel", "", a04);
        Ingredient i06 = new Ingredient("Crevettes", "Shrimp", "", a02);
        Ingredient i07 = new Ingredient("Calamar", "Squid", "", a04);
        Ingredient i08 = new Ingredient("Bonite", "Bonite", "", a04);
        //Ingredient i09 = new Ingredient("Crevettes", "Shrimp", "");
        Ingredient i25 = new Ingredient("Anguilles", "Ell", "", a04);
        //legumes
        Ingredient i11 = new Ingredient("Choux chinois", "Chinese cabbage", "");
        Ingredient i12 = new Ingredient("Legumes", "Vegetables", "");
        Ingredient i22 = new Ingredient("Pommes de terre", "Potatoes", "");
        Ingredient i26 = new Ingredient("Soja", "Soybean", "", a06);
        Ingredient i27 = new Ingredient("Poireau", "Leek", "");
        Ingredient i29 = new Ingredient("Maïs", "Corn", "");
        Ingredient i31 = new Ingredient("Pois gourmands", "Snow peas", "");
        Ingredient i32 = new Ingredient("Pousses bambou", "Bamboo grows", "");
        Ingredient i33 = new Ingredient("Gingembre", "Ginger", "");
        Ingredient i34 = new Ingredient("Radis", "Radish", "");
        Ingredient i40 = new Ingredient("Haricot rouge", "Blackbean", "");
        
        //pates + accompagnements
        Ingredient i14 = new Ingredient("Ramen (farine de blé)", "Ramen (wheat flour)", "", a01);
        Ingredient i15 = new Ingredient("Soba (farine de sarasin)", "Soba (buckwheat flour)", "", a01);
        Ingredient i16 = new Ingredient("Udon (forment, blé tendre)", "Udon (soft flour)", "", a01);
        Ingredient i19 = new Ingredient("Nouilles", "Noddles", "", a01);
        Ingredient i17 = new Ingredient("Riz blanc", "White rice", "");
        Ingredient i18 = new Ingredient("Riz sauté", "Cantonese rice", "");
        Ingredient i35 = new Ingredient("Riz vinaigré", "Japanese rice", "");        
        
        //condiments
        Ingredient i13 = new Ingredient("Miso", "Miso", "", a06);
        Ingredient i23 = new Ingredient("Curry", "Curry", "");
        Ingredient i24 = new Ingredient("Sauce soja", "Soy sauce", "", a06);
        Ingredient i28 = new Ingredient("Tofu", "Tofu", "", a06);
        Ingredient i30 = new Ingredient("Algues", "Seaweed", "");
        Ingredient i36 = new Ingredient("Beurre", "Butter", "", a07);
        Ingredient i37 = new Ingredient("Lait", "Milk", "", a07);
        Ingredient i38 = new Ingredient("Café", "Coffee", "");
        Ingredient i39 = new Ingredient("Gelatine", "Gelatine", "");
        Ingredient i41 = new Ingredient("Thé matcha", "Matcha tea", "");
        
        
        em.persist(i01);
        em.persist(i02);
        em.persist(i03);
        em.persist(i04);
        em.persist(i05);
        em.persist(i06);
        em.persist(i07);
        em.persist(i08);
        em.persist(i10);
        em.persist(i11);
        em.persist(i13);
        em.persist(i14);
        em.persist(i15);
        em.persist(i16);
        em.persist(i17);
        em.persist(i18);
        em.persist(i19);
        em.persist(i20);
        em.persist(i21);
        em.persist(i22);
        em.persist(i23);
        em.persist(i24);
        em.persist(i25);
        em.persist(i26);
        em.persist(i27);
        em.persist(i28);
        em.persist(i29);
        em.persist(i30);
        em.persist(i31);
        em.persist(i32);
        em.persist(i33);
        em.persist(i34);
        em.persist(i35);
        em.persist(i36);
        em.persist(i37);
        em.persist(i38);
        em.persist(i39);
        em.persist(i40);
        em.persist(i41);
        em.flush();
        
        // Création des ingredients dans les plats
        Collection<Ingredient> prodings = p001.getIngredients();
        prodings.add(i02);
        prodings.add(i14);

        prodings = p002.getIngredients();
        prodings.add(i02);
        prodings.add(i24);
        prodings.add(i14);

        prodings = p003.getIngredients();
        prodings.add(i27);
        prodings.add(i24);
        prodings.add(i14);        
        
        prodings = p004.getIngredients();
        prodings.add(i14);        

        prodings = p005.getIngredients();
        prodings.add(i14);        

        prodings = p006.getIngredients();
        prodings.add(i14);        
        prodings.add(i02);        
        prodings.add(i11);        

        prodings = p007.getIngredients();
        prodings.add(i14);        
        prodings.add(i24);        
        
        // Création des restaurants
        Restaurant r01 = new Restaurant("362 521 879", "NoSushi-Paris");
        Restaurant r02 = new Restaurant("362 521 880", "NoSushi-Creteil");
        
        em.persist(r01);
        em.persist(r02);
        em.flush();
        
        // Création des clients
        Client c01 = new Client("Dighs1950", "Lemelin", "Aubin", "dee5Ej7Ei", "AubinLemelin@jourrapide.com", "10214125");
        Client c02 = new Client("Harespok", "Laderoute", "Jean", "aexaiX5y", "JeanLaderoute@dayrep.com", "14255387");
        Client c03 = new Client("Hiceivien", "Bouvier", "Lucie", "Eivee4OoZem", "LucieBouvier@rhyta.com", "20145369");
        Client c04 = new Client("Whatepok", "Gousse", "Franck ", "Bu1eicoi3", "FranckGousse@rhyta.com", "12345678");

        em.persist(c01);
        em.persist(c02);
        em.persist(c03);
        em.persist(c04);
        em.flush();

        // Création des messages
        Date d = new GregorianCalendar().getTime();
        
        Message mess01 = new Message("INF", "Bienvenue chez NoSushi", "Message utilisé dans l'écran d'accueil", d, null, r01);
        Message mess02 = new Message("ERR", "Erreur de connexion", "", d, null, r01);
        Message mess03 = new Message("VAL", "Votre commande a été validée", "", d, null, r01);
        Message mess04 = new Message("DEL", "Le produit a été supprimé", "", d, null, r01);
        Message mess05 = new Message("DEL", "Votre panier a bien été vidé", "Message de confirmation panier vidé", d, null, r01);
        Message mess06 = new Message("MAJ", "Votre panier a été mis a jour", "", d, null, r01);
        
        em.persist(mess01);
        em.persist(mess02);
        em.persist(mess03);
        em.persist(mess04);
        em.persist(mess05);
        em.persist(mess06);
        em.flush();

        // Création paiements - mis en commentaire car le paiement sera généré en fonction des commandes passées pour avoir des données cohérentes
        Date d01 = new GregorianCalendar().getTime();
        Paiement pmt01 = new Paiement(d01, "Carte bancaire", 14.07f);
        Paiement pmt02 = new Paiement(d01, "Carte bancaire", 22.14f);
        Paiement pmt03 = new Paiement(d01, "Carte bancaire", 7.22f);

        em.persist(pmt01);
        em.persist(pmt02);
        em.persist(pmt03);
        em.flush();

        // Création des commandes
        Commande cmd01 = new Commande (d01, "VALIDE");
        Commande cmd02 = new Commande (d01, "PAYE");
        
        em.persist(cmd01);
        em.persist(cmd02);
        em.flush();

        // Création des lignes de commande
        LigneCommande lc01 = new LigneCommande (1, 10f, cmd01);
        LigneCommande lc02 = new LigneCommande (1, 5f, cmd01);
        LigneCommande lc03 = new LigneCommande (2, 4f, cmd01);
        LigneCommande lc04 = new LigneCommande (1, 10f, cmd02);
        LigneCommande lc05 = new LigneCommande (2, 4.5f, cmd02);
        
        em.persist(lc01);
        em.persist(lc02);
        em.persist(lc03);
        em.persist(lc04);
        em.persist(lc05);
        em.flush();
        
        // Création lien lignecmd et produits
        Collection<Produit> produitscmd = lc01.getProduits();
        produitscmd.add(p009);
        
        produitscmd = lc02.getProduits();
        produitscmd.add(p056);
        
        produitscmd = lc03.getProduits();
        produitscmd.add(p094);
        
        produitscmd = lc04.getProduits();
        produitscmd.add(p071);
        
        produitscmd = lc05.getProduits();
        produitscmd.add(p101);
        
        // Création TVA
        Tva t01 = new Tva("Tvaboisson",5.5f );
        Tva t02 = new Tva("TvaNourriture",10.0f); 
        Tva t03 = new Tva("Tvaalcohol",20.0f );
         
        em.persist(t01);
        em.persist(t02);
        em.persist(t03);
            
        em.flush();
        
        // Création lien produits et TVA
        p093.setTva(t02);
        
        // Création des options        
        Choix Op01 = new Choix("4 Tranches de porc", "4 slices of pork", 1, 1.0f);
        Choix Op02 = new Choix("Beurre", "Butter", 1, 1.0f);
        Choix Op03 = new Choix("Œuf cuit", "Boiled egg", 1, 1.0f);
        Choix Op04 = new Choix("Pousses de bambou", "Bamboo shoots", 1, 1.0f);
        Choix Op05 = new Choix("Algues", "Seaweed", 1, 1.0f);
        Choix Op06 = new Choix("Maïs", "Corn", 1, 1.0f);
        Choix Op07 = new Choix("Légumes marinés", "pickles", 1, 1.0f);

        em.persist(Op01);
        em.persist(Op02);
        em.persist(Op03);
        em.persist(Op04);
        em.persist(Op05);
        em.persist(Op06);
        em.persist(Op07);
 
        em.flush();

    }
}
