package ejb;

import javax.ejb.Local;

@Local
public interface CreationDonneesProduitLocal {

    public void CreationDonneesProduit();
    
}
