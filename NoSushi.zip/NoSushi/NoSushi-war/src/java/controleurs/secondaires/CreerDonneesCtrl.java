package controleurs.secondaires;

import controleurs.SousControleurInterface;
import ejb.CreationDonneesProduitLocal;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CreerDonneesCtrl implements Serializable, SousControleurInterface {    
    
    public String executer(HttpServletRequest request, HttpServletResponse response){
        CreationDonneesProduitLocal creationDonnees = lookupCreationDonneesLocal();
        try {
                creationDonnees.CreationDonneesProduit();
                request.setAttribute("msg", "Création des données terminée!");
            } catch (RuntimeException ex) {
                request.setAttribute("msgErr", "Les données existent déjà");
            }
            return "/WEB-INF/home.jsp";
    }

    private CreationDonneesProduitLocal lookupCreationDonneesLocal() {
        try {
            Context c = new InitialContext();
            return (CreationDonneesProduitLocal) c.lookup("java:global/NoSushi/NoSushi-ejb/CreationDonneesProduit!ejb.CreationDonneesProduitLocal");
        } catch (NamingException ne) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
            throw new RuntimeException(ne);
        }
    }
}
