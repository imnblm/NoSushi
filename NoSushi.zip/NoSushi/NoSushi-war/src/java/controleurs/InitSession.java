
package controleurs;

import java.io.Serializable;
import javax.servlet.http.HttpSession;


class InitSession implements Serializable{

    void init(HttpSession session) {
    }
    
}
